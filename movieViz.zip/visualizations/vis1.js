/*
todo
1. text field to choose how many movies
2. click to sort by budget, revenue
3. check boxes to filter on type of movie
4. on hover for more specific data
5. 
*/


function vis1(data, div) {
  const margin = {top: 40, right: 20, bottom: 40, left: 200};

  const visWidth = 1400 - margin.left - margin.right;
  const visHeight = 800 - margin.top - margin.bottom;

  const svg = div.append('svg')
      .attr('width', visWidth + margin.left + margin.right)
      .attr('height', visHeight + margin.top + margin.bottom);

  const g = svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`);

  function update(nValue) {
    filteredData = data.slice()
      .sort((a, b) => d3.descending(a.budget, b.budget))
      .slice(0, nValue.value);
      
    console.log(nValue);
    console.log(filteredData);
    return filteredData;
  }

  d3.select("#nValue").on("input", function() {
    filteredData = update(this.value);
  });
  
  console.log(nValue.value);

  // add title
  g.append("text")
    .attr("x", visWidth / 2)
    .attr("y", -margin.top + 5)
    .attr("text-anchor", "middle")
    .attr("dominant-baseline", "hanging")
    .attr("font-family", "sans-serif")
    .attr("font-size", "16px")
    .text("movie stuff");

  // create scales

  const x = d3.scaleLinear()
    .domain([-d3.max(filteredData, d => d.budget), d3.max(filteredData, d => d.revenue)]).nice()
    .range([0, visWidth]);

  const filterTitleMap = filteredData.sort((a, b) => d3.descending(a.budget, b.budget))
      .map(d => d.title);

  const y = d3.scaleBand()
    .domain(filterTitleMap)
    .range([0, visHeight])
    .padding(0.2);

  // create and add axes

  const xAxis = d3.axisBottom(x);
  g.append("g")
    .attr("transform", `translate(0, ${visHeight})`)
    .call(xAxis)
    .call(g => g.selectAll(".domain").remove())
    .append("text")
    .attr("x", visWidth / 2)
    .attr("y", 40)
    .attr("fill", "black")
    .attr("text-anchor", "middle")
    .text("Red = budget, Blue = revenue");

  const yAxis = d3.axisLeft(y);

  g.append("g")
    .call(yAxis)
    .call(g => g.selectAll(".domain").remove());

  // draw revenue bars

  g.selectAll(".revenue-bars")
    .data(filteredData)
    .join("rect")
    .attr("class", "revenue-bars")
    .attr("x", d => x(0)) //start graph at amount = 0
    .attr("y", d => y(d.title))
    .attr("width", d => (x(d.revenue) - x(0))) // change width so it assumes we start at 0
    .attr("height", d => y.bandwidth())
    .attr("fill", "steelblue");

  // draw budget bars
  
  g.selectAll(".budget-bars")
    .data(filteredData)
    .join("rect")
    .attr("class", "budget-bars")
    .attr("x", d => x(-d.budget)) //start rect at amount donated left
    .attr("y", d => y(d.title))
    .attr("width", d => (x(0) - x(-d.budget))) // change width so rect ends at 0 
    .attr("height", d => y.bandwidth())
    .attr("fill", "red");
    
  }
